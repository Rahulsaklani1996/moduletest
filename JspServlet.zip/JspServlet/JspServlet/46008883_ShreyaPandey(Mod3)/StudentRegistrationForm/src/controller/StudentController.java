package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentController
 */
@WebServlet("/StudentController")
public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String mobnum = request.getParameter("mobnum");
		String percent = request.getParameter("percent");
		boolean fl = false;
		if(mobnum.length() == 10)
		{char[] ch = mobnum.toCharArray();
			for(int i = 0;i<10;i++)
			{
				
				if(Character.isDigit(ch[i]))
				{
					fl = true;
				}
			}
		}
		
		if(Double.parseDouble(percent) > 100.0 && Double.parseDouble(percent) < 0.0)
		{
			fl = false;
		}
		
		if(fl)
		{
			response.sendRedirect("Success.jsp?per="+percent);
			//response.getWriter().print("Data Has Been Successfully Stored. Your percentage are :" + mark );
		}
}
	}
